using Microsoft.AspNetCore.Mvc.RazorPages;

namespace GymWorkoutRoutines.Pages.Workouts
{
    public class StrengthModel : PageModel
    {
        public void OnGet()
        {
            // Any logic you want to execute when the page is requested.
        }
    }
}
