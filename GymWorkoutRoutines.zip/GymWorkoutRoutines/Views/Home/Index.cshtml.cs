using Microsoft.AspNetCore.Mvc.RazorPages;

namespace GymWorkoutRoutines.Views.Home
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
            // Any logic you want to execute when the page is requested.
        }
    }
}
